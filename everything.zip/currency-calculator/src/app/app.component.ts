import { CurrencyService } from './../shared/currency.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  currencies = [];
  title = 'app';
  apiStatus: string;
  constructor(private _currencySrv: CurrencyService) { } 

  ngOnInit() {
    this._currencySrv.index<Object[]>().subscribe( 
      currencies => {
        console.log(currencies);  
        this.currencies = currencies.data;
      });
  }

  refresh() {
    this._currencySrv.refresh<Object[]>().subscribe( 
      currencies => this.currencies = currencies.data);
  }

}
